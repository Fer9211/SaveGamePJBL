import "../styles/lista.css";
function Lista(){
    return(
        <div className="lista">
            <div className="componente">
                <div className="componenteEsquerda">
                    <img src="./assets/images/capaEuroTruck.webp" />
                </div>
                <div className="componenteDireita">

                </div>
            </div>
        </div>
    )
}
export default Lista;