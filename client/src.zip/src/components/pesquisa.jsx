import "../styles/pesquisa.css";
function Pesquisa(){
    return(
        <div className="pesquisa">
            <input className="barraPesquisa" type="text" placeholder="Pesquisar..."/>
            <button className="btn-pesquisa">Adicionar novo jogo</button>
        </div>
    )
}
export default Pesquisa;