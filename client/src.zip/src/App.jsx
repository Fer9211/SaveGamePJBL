
import "./styles/AppStyle.css"
import './App.css'
import "./components/pesquisa.jsx"
import "./components/lista.jsx"
import Pesquisa from "./components/pesquisa.jsx"
function App() {

  return (
    <div className='app'>
      <nav className='navApp'>
        <div><h1 className='title'>SAVE GAME</h1></div>
      </nav>
    
      <div className="conteiner">
        <Pesquisa/>
        <Lista/>
      </div>

      <footer className='footer'>
        <p>Save Game - Desenvolvido por: <strong>Fernanda Costa Moraes</strong></p>
      </footer>
    </div>

  )
}

export default App
